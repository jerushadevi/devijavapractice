public class Array1
{
	public static void main(String[] args) {
	    //intialization
		int a[]={12,45,67,23,89,67};
	
		//print array elements
		System.out.println("array elements are");
		for(int i=0;i<a.length;i++)//i=5
		{
		System.out.println(a[i]);
		}
		
	}
}

