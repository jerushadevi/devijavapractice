public class Main4
{
	public static void main(String[] args) {
		int a[]=new int[5];
		a[0]=23;
		a[1]=14;
		a[2]=12;
		a[3]=98;
		a[4]=25;
		
		//print array elements
		for(int i=0;i<5;i++)//i=5
		{
		System.out.println(a[i]);
		}
		//one value
		System.out.println(a[4]);
	}
}
