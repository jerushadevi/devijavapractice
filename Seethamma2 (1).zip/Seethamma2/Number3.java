class Number3
{
    public static void main(String args[])
    {
      int i=1;
        do
        {
            System.out.println("bitlabs");
            i++;
        }while(i<=10);//exit controlled loop
         
    }
}
